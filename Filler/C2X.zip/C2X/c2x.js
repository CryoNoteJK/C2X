//const commando = require('discord.js-commando');
/*bot.registry.registerGroup('random', 'Random');
bot.registry.registerDefaults();
bot.registry.registerCommandsIn(__dirname + '/commands');*/

const Discord = require('discord.js');
const bot = new Discord.Client();
const newUsers = new Discord.Collection();
const fs = require("fs");
var place;
var question;
var answer;
var ranQues;
var response;
var server;
var user;
var code = fs.readFileSync("./textFiles/codeOfConduct.txt", {"encoding": "utf-8"});
var questions = fs.readFileSync("./textFiles/Questions.txt", {"encoding": "utf-8"});
var quesArray = questions.split('\n');
var answers = fs.readFileSync("./textFiles/Answers.txt", {"encoding": "utf-8"});
var ansArray = answers.split('\n');

bot.on('guildMemberAdd', (member) => {
   // newUsers.set(member.id, member.user);
    server = member.guild;
    user = member.client;
    member.sendMessage(code);
    ranQues = (Math.floor(Math.random() * 10));
    question = quesArray[ranQues];
    member.sendMessage(question);
    place = 0;
});

bot.on('message', function(message){
    response = message.content;
    answer = ansArray[ranQues].trim();
    if (place == 0){
        if (message.channel.type == 'dm'){
            console.log ('1');
            if (answer == response){
                console.log ('2');
                message.author.send('Correct! welcome to the server.');
                //community = server.roles.get("@&512039350377250820");
                server.members.get(message.author.id).addRole('512039350377250820')
                place = 1;
            }
            if (message.author.bot!=true && place == 0){  
                console.log ('3');
                message.author.send('Not quite, try again!');
                ranQues = (Math.floor(Math.random() * 10));
                question = quesArray[ranQues];
                answer = ansArray[ranQues].trim();
                message.author.send(question);
            };
        };
    };
});
bot.on("guildMemberRemove", (member) => {
    if(newUsers.has(member.id)) newUsers.delete(member.id);
  });


bot.login('NTExNjg4MTY0MjI2ODkxNzc3.Dsuuww.nQiLp1CCUaYD2dRcT37nrn5PxKk');