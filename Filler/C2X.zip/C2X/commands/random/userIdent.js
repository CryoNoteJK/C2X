const commando = require('discord.js-commando');

class DiceRollCommand extends commando.Command {

    constructor(client) {
        super(client, {
            name: 'Ident',
            group: 'random',
            memberName: 'Ident',
            description: 'Identifies new user.',
            examples: ['reply']
        });    
    }



};