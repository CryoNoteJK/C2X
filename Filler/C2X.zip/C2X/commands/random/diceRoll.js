const commando = require('discord.js-commando');

class DiceRollCommand extends commando.Command {

    constructor(client){
        super(client, {
            name: 'roll',
            group: 'random',
            memberName: 'roll',
            description: 'Rolls an X sided die Y times and outputs the total.',
            args: [
                {
                key: 'X',
                prompt: 'How many sides on the die?',
                type: 'integer',            
                },
                {
                key: 'Y',
                prompt: 'How many rolls?',
                type: 'integer',
                },
            ]
        });
    };

    run(msg, {X, Y}){
        var roll = 0;
        var i;

        for (i =0; i < Y; i++){
            var roll = roll + (Math.floor(Math.random() * X) + 1);
        };  
         
        msg.reply('You rolled a ' + roll + '!');

    }
};

module.exports = DiceRollCommand;